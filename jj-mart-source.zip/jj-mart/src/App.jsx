import { useState } from 'react'
import { Routes, Route, Link } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { CartProvider } from './context/CartContext'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import CategoryPage from './pages/CategoryPage'
import ProductDetail from './pages/ProductDetail'
import Cart from './pages/Cart'
import Checkout from './pages/Checkout'
import Login from './pages/Login'
import Orders from './pages/Orders'
import Account from './pages/Account'
import Search from './pages/Search'
import Admin from './pages/Admin'
import './styles.css'

function LoginPrompt({ onClose }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-card" onClick={e => e.stopPropagation()} style={{ textAlign: 'center' }}>
        <span style={{ fontSize: 40 }}>🔒</span>
        <h3 style={{ margin: '10px 0' }}>Log in to continue</h3>
        <p style={{ color: 'var(--gray)', fontSize: 14, marginBottom: 18 }}>Please log in or create an account to add items to your cart.</p>
        <Link to="/login" className="btn btn-primary" style={{ width: '100%' }} onClick={onClose}>Log In / Sign Up</Link>
      </div>
    </div>
  )
}

function AppShell() {
  const [showLogin, setShowLogin] = useState(false)
  const onNeedLogin = () => setShowLogin(true)

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Header />
      <main style={{ flex: 1 }}>
        <Routes>
          <Route path="/" element={<Home onNeedLogin={onNeedLogin} />} />
          <Route path="/category/:slug" element={<CategoryPage onNeedLogin={onNeedLogin} />} />
          <Route path="/product/:slug" element={<ProductDetail onNeedLogin={onNeedLogin} />} />
          <Route path="/search" element={<Search onNeedLogin={onNeedLogin} />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/login" element={<Login />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/account" element={<Account />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="*" element={
            <div className="empty-state">
              <span className="emoji">🤔</span>
              <h3>Page not found</h3>
              <Link to="/" className="btn btn-secondary" style={{ marginTop: 12 }}>Back to home</Link>
            </div>
          } />
        </Routes>
      </main>
      <Footer />
      {showLogin && <LoginPrompt onClose={() => setShowLogin(false)} />}
    </div>
  )
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <AppShell />
      </CartProvider>
    </AuthProvider>
  )
}
