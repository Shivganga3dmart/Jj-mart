export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <h4>JJ Mart</h4>
            <p>Your neighborhood superstore, online. Fresh groceries and daily essentials delivered fast.</p>
          </div>
          <div>
            <h4>Shop</h4>
            <a href="/">All Products</a>
            <a href="/category/fruits-vegetables">Fruits & Vegetables</a>
            <a href="/category/staples">Staples</a>
            <a href="/category/household-cleaning">Household</a>
          </div>
          <div>
            <h4>Account</h4>
            <a href="/orders">My Orders</a>
            <a href="/account">My Account</a>
            <a href="/cart">My Cart</a>
          </div>
          <div>
            <h4>Help</h4>
            <p>support@jjmart.example</p>
            <p>Mon–Sun, 8am–10pm</p>
          </div>
        </div>
        <div className="footer-bottom">
          © 2026 JJ Mart Superstore. Built as a demo project — not a real store.
        </div>
      </div>
    </footer>
  )
}
