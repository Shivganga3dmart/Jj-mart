import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'

const emptyProduct = { name: '', slug: '', description: '', category_id: '', brand: '', unit: '1 pc', mrp: '', price: '', stock: '', image_url: '' }

export default function Admin() {
  const { user, profile, loading: authLoading } = useAuth()
  const [tab, setTab] = useState('products')
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])
  const [orders, setOrders] = useState([])
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState(emptyProduct)
  const [loading, setLoading] = useState(true)
  const [toast, setToast] = useState('')

  useEffect(() => {
    if (profile?.is_admin) loadAll()
  }, [profile])

  async function loadAll() {
    setLoading(true)
    const { data: cats } = await supabase.from('categories').select('*').order('sort_order')
    setCategories(cats || [])
    const { data: prods } = await supabase.from('products').select('*, category:categories(name)').order('created_at', { ascending: false })
    setProducts(prods || [])
    const { data: ords } = await supabase.from('orders').select('*, items:order_items(*)').order('created_at', { ascending: false })
    setOrders(ords || [])
    setLoading(false)
  }

  function showToast(msg) {
    setToast(msg)
    setTimeout(() => setToast(''), 2500)
  }

  function slugify(s) {
    return s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
  }

  function openNew() {
    setForm(emptyProduct)
    setEditing('new')
  }

  function openEdit(p) {
    setForm({
      name: p.name, slug: p.slug, description: p.description || '', category_id: p.category_id || '',
      brand: p.brand || '', unit: p.unit, mrp: p.mrp, price: p.price, stock: p.stock, image_url: p.image_url || ''
    })
    setEditing(p.id)
  }

  async function saveProduct(e) {
    e.preventDefault()
    const payload = {
      ...form,
      slug: form.slug || slugify(form.name),
      mrp: Number(form.mrp), price: Number(form.price), stock: Number(form.stock),
      category_id: form.category_id || null
    }
    if (editing === 'new') {
      const { error } = await supabase.from('products').insert(payload)
      if (error) { showToast('Error: ' + error.message); return }
      showToast('Product added!')
    } else {
      const { error } = await supabase.from('products').update(payload).eq('id', editing)
      if (error) { showToast('Error: ' + error.message); return }
      showToast('Product updated!')
    }
    setEditing(null)
    loadAll()
  }

  async function toggleActive(p) {
    await supabase.from('products').update({ is_active: !p.is_active }).eq('id', p.id)
    loadAll()
  }

  async function deleteProduct(id) {
    if (!confirm('Delete this product permanently?')) return
    await supabase.from('products').delete().eq('id', id)
    showToast('Product deleted')
    loadAll()
  }

  async function updateOrderStatus(orderId, status) {
    await supabase.from('orders').update({ status }).eq('id', orderId)
    loadAll()
    showToast(`Order marked as ${status}`)
  }

  if (authLoading) return <div className="spinner-wrap">Loading…</div>

  if (!user) {
    return (
      <div className="empty-state">
        <span className="emoji">🔒</span>
        <h3>Please log in</h3>
        <Link to="/login" className="btn btn-secondary" style={{ marginTop: 12 }}>Login</Link>
      </div>
    )
  }

  if (!profile?.is_admin) {
    return (
      <div className="empty-state">
        <span className="emoji">⛔</span>
        <h3>Admin access required</h3>
        <p>Your account doesn't have admin privileges.</p>
        <Link to="/" className="btn btn-secondary" style={{ marginTop: 12 }}>Back to Home</Link>
      </div>
    )
  }

  return (
    <div className="container">
      <div className="page-head"><h1>Admin Dashboard</h1></div>

      <div className="admin-layout" style={{ paddingBottom: 50 }}>
        <div className="admin-nav">
          <button className={tab === 'products' ? 'active' : ''} onClick={() => setTab('products')}>📦 Products ({products.length})</button>
          <button className={tab === 'orders' ? 'active' : ''} onClick={() => setTab('orders')}>🧾 Orders ({orders.length})</button>
          <button className={tab === 'categories' ? 'active' : ''} onClick={() => setTab('categories')}>🗂 Categories ({categories.length})</button>
        </div>

        <div>
          {loading ? <div className="spinner-wrap">Loading…</div> : (
            <>
              {tab === 'products' && (
                <>
                  <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 14 }}>
                    <button className="btn btn-primary" onClick={openNew}>+ Add Product</button>
                  </div>
                  <table className="admin-table">
                    <thead>
                      <tr><th></th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr>
                    </thead>
                    <tbody>
                      {products.map(p => (
                        <tr key={p.id}>
                          <td><img src={p.image_url} alt="" /></td>
                          <td>{p.name}<br /><span style={{ color: 'var(--gray)', fontSize: 11 }}>{p.unit}</span></td>
                          <td>{p.category?.name || '—'}</td>
                          <td>₹{p.price}</td>
                          <td>{p.stock}</td>
                          <td>
                            <span style={{ color: p.is_active ? 'var(--green)' : 'var(--orange)', fontWeight: 700, fontSize: 12 }}>
                              {p.is_active ? 'Active' : 'Hidden'}
                            </span>
                          </td>
                          <td>
                            <button className="icon-btn" onClick={() => openEdit(p)}>Edit</button>
                            <button className="icon-btn" onClick={() => toggleActive(p)}>{p.is_active ? 'Hide' : 'Show'}</button>
                            <button className="icon-btn" onClick={() => deleteProduct(p.id)}>Delete</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </>
              )}

              {tab === 'orders' && (
                <table className="admin-table">
                  <thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Total</th><th>Status</th><th>Update</th></tr></thead>
                  <tbody>
                    {orders.map(o => (
                      <tr key={o.id}>
                        <td>#{o.id.slice(0, 8).toUpperCase()}<br /><span style={{ color: 'var(--gray)', fontSize: 11 }}>{new Date(o.created_at).toLocaleDateString()}</span></td>
                        <td>{o.delivery_name}<br /><span style={{ color: 'var(--gray)', fontSize: 11 }}>{o.delivery_phone}</span></td>
                        <td>{o.items.length} item(s)</td>
                        <td>₹{o.total}</td>
                        <td><span className={`order-status status-${o.status}`}>{o.status}</span></td>
                        <td>
                          <select value={o.status} onChange={e => updateOrderStatus(o.id, e.target.value)} style={{ padding: '4px 8px', borderRadius: 4, border: '1px solid var(--border)' }}>
                            {['placed', 'packed', 'shipped', 'delivered', 'cancelled'].map(s => <option key={s} value={s}>{s}</option>)}
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {tab === 'categories' && (
                <table className="admin-table">
                  <thead><tr><th>Icon</th><th>Name</th><th>Slug</th><th>Products</th></tr></thead>
                  <tbody>
                    {categories.map(c => (
                      <tr key={c.id}>
                        <td style={{ fontSize: 20 }}>{c.icon}</td>
                        <td>{c.name}</td>
                        <td style={{ color: 'var(--gray)' }}>{c.slug}</td>
                        <td>{products.filter(p => p.category_id === c.id).length}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </>
          )}
        </div>
      </div>

      {editing && (
        <div className="modal-overlay" onClick={() => setEditing(null)}>
          <div className="modal-card" onClick={e => e.stopPropagation()}>
            <h3 style={{ marginBottom: 14 }}>{editing === 'new' ? 'Add Product' : 'Edit Product'}</h3>
            <form onSubmit={saveProduct}>
              <div className="field"><label>Name *</label><input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></div>
              <div className="field"><label>Slug (auto if blank)</label><input value={form.slug} onChange={e => setForm({ ...form, slug: e.target.value })} placeholder="auto-generated from name" /></div>
              <div className="field"><label>Category</label>
                <select value={form.category_id} onChange={e => setForm({ ...form, category_id: e.target.value })}>
                  <option value="">— None —</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
                </select>
              </div>
              <div className="field"><label>Brand</label><input value={form.brand} onChange={e => setForm({ ...form, brand: e.target.value })} /></div>
              <div className="field"><label>Unit (e.g. 1 kg, 500 ml)</label><input value={form.unit} onChange={e => setForm({ ...form, unit: e.target.value })} /></div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                <div className="field"><label>MRP (₹) *</label><input required type="number" step="0.01" value={form.mrp} onChange={e => setForm({ ...form, mrp: e.target.value })} /></div>
                <div className="field"><label>Selling Price (₹) *</label><input required type="number" step="0.01" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} /></div>
              </div>
              <div className="field"><label>Stock *</label><input required type="number" value={form.stock} onChange={e => setForm({ ...form, stock: e.target.value })} /></div>
              <div className="field"><label>Image URL</label><input value={form.image_url} onChange={e => setForm({ ...form, image_url: e.target.value })} /></div>
              <div className="field"><label>Description</label><textarea rows={3} value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} /></div>
              <div style={{ display: 'flex', gap: 10 }}>
                <button type="submit" className="btn btn-primary">{editing === 'new' ? 'Add Product' : 'Save Changes'}</button>
                <button type="button" className="btn btn-outline" onClick={() => setEditing(null)}>Cancel</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  )
}
