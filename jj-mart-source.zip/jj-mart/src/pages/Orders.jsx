import { useEffect, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'

export default function Orders() {
  const { user } = useAuth()
  const [searchParams] = useSearchParams()
  const justPlaced = searchParams.get('placed')
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [reviewingProduct, setReviewingProduct] = useState(null)
  const [reviewText, setReviewText] = useState('')
  const [reviewRating, setReviewRating] = useState(5)

  useEffect(() => {
    if (!user) return
    loadOrders()
  }, [user])

  async function loadOrders() {
    setLoading(true)
    const { data } = await supabase
      .from('orders')
      .select('*, items:order_items(*)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
    setOrders(data || [])
    setLoading(false)
  }

  async function submitReview(productId) {
    await supabase.from('reviews').upsert({
      product_id: productId, user_id: user.id, rating: reviewRating, comment: reviewText
    }, { onConflict: 'product_id,user_id' })

    // Recalculate product rating
    const { data: allReviews } = await supabase.from('reviews').select('rating').eq('product_id', productId)
    if (allReviews && allReviews.length > 0) {
      const avg = allReviews.reduce((s, r) => s + r.rating, 0) / allReviews.length
      await supabase.from('products').update({ rating: avg.toFixed(1), rating_count: allReviews.length }).eq('id', productId)
    }
    setReviewingProduct(null)
    setReviewText('')
    setReviewRating(5)
  }

  if (!user) {
    return (
      <div className="empty-state">
        <span className="emoji">🔒</span>
        <h3>Please log in to view your orders</h3>
        <Link to="/login" className="btn btn-secondary" style={{ marginTop: 12 }}>Login</Link>
      </div>
    )
  }

  if (loading) return <div className="spinner-wrap">Loading your orders…</div>

  return (
    <div className="container">
      <div className="page-head"><h1>My Orders</h1></div>

      {justPlaced && (
        <div className="form-success" style={{ maxWidth: 600 }}>
          🎉 Order placed successfully! You'll see it below — track its status here anytime.
        </div>
      )}

      {orders.length === 0 ? (
        <div className="empty-state">
          <span className="emoji">📦</span>
          <h3>No orders yet</h3>
          <p>Your order history will show up here.</p>
          <Link to="/" className="btn btn-secondary" style={{ marginTop: 12 }}>Start Shopping</Link>
        </div>
      ) : (
        <div style={{ paddingBottom: 50, maxWidth: 700 }}>
          {orders.map(order => (
            <div className="order-card" key={order.id}>
              <div className="order-card-head">
                <div>
                  <strong>Order #{order.id.slice(0, 8).toUpperCase()}</strong>
                  <div style={{ fontSize: 12.5, color: 'var(--gray)' }}>
                    {new Date(order.created_at).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </div>
                </div>
                <span className={`order-status status-${order.status}`}>{order.status}</span>
              </div>

              {order.items.map(item => (
                <div className="order-item-row" key={item.id}>
                  <span>{item.product_name} <span className="muted">× {item.quantity} ({item.unit})</span></span>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <span>₹{(item.price * item.quantity).toFixed(0)}</span>
                    {order.status === 'delivered' && item.product_id && (
                      <button className="icon-btn" onClick={() => setReviewingProduct(item.product_id)}>Rate</button>
                    )}
                  </div>
                </div>
              ))}

              <div className="order-item-row" style={{ borderTop: '1px dashed var(--border)', marginTop: 8, paddingTop: 10, fontWeight: 700 }}>
                <span>Total ({order.payment_method === 'cod' ? 'Cash on Delivery' : 'Paid Online'})</span>
                <span>₹{order.total}</span>
              </div>
              <p style={{ fontSize: 12.5, color: 'var(--gray)', marginTop: 6 }}>Delivering to: {order.delivery_address}</p>
            </div>
          ))}
        </div>
      )}

      {reviewingProduct && (
        <div className="modal-overlay" onClick={() => setReviewingProduct(null)}>
          <div className="modal-card" onClick={e => e.stopPropagation()}>
            <h3 style={{ marginBottom: 14 }}>Rate this product</h3>
            <div className="field">
              <label>Rating</label>
              <select value={reviewRating} onChange={e => setReviewRating(Number(e.target.value))}>
                {[5, 4, 3, 2, 1].map(n => <option key={n} value={n}>{n} stars</option>)}
              </select>
            </div>
            <div className="field">
              <label>Comment (optional)</label>
              <textarea rows={3} value={reviewText} onChange={e => setReviewText(e.target.value)} />
            </div>
            <div style={{ display: 'flex', gap: 10 }}>
              <button className="btn btn-primary" onClick={() => submitReview(reviewingProduct)}>Submit Review</button>
              <button className="btn btn-outline" onClick={() => setReviewingProduct(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
