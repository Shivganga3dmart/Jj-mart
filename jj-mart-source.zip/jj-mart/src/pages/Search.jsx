import { useEffect, useState } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import ProductCard from '../components/ProductCard'

export default function Search({ onNeedLogin }) {
  const [searchParams] = useSearchParams()
  const q = searchParams.get('q') || ''
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function load() {
      setLoading(true)
      const { data } = await supabase
        .from('products')
        .select('*')
        .eq('is_active', true)
        .or(`name.ilike.%${q}%,brand.ilike.%${q}%,description.ilike.%${q}%`)
      setProducts(data || [])
      setLoading(false)
    }
    if (q) load()
  }, [q])

  return (
    <div className="container">
      <div className="page-head">
        <div className="breadcrumb"><Link to="/">Home</Link> / Search</div>
        <h1>Results for "{q}"</h1>
      </div>

      {loading ? (
        <div className="spinner-wrap">Searching…</div>
      ) : products.length === 0 ? (
        <div className="empty-state">
          <span className="emoji">🔍</span>
          <h3>No products found</h3>
          <p>Try searching for something like "rice", "soap", or "milk".</p>
        </div>
      ) : (
        <div className="product-grid" style={{ paddingBottom: 40 }}>
          {products.map(p => <ProductCard key={p.id} product={p} onNeedLogin={onNeedLogin} />)}
        </div>
      )}
    </div>
  )
}
