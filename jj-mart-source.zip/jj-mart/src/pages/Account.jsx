import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'

export default function Account() {
  const { user, profile, refreshProfile } = useAuth()
  const [addresses, setAddresses] = useState([])
  const [form, setForm] = useState({ full_name: '', phone: '' })
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (profile) setForm({ full_name: profile.full_name || '', phone: profile.phone || '' })
  }, [profile])

  useEffect(() => {
    if (!user) return
    supabase.from('addresses').select('*').eq('user_id', user.id).then(({ data }) => setAddresses(data || []))
  }, [user])

  if (!user) {
    return (
      <div className="empty-state">
        <span className="emoji">🔒</span>
        <h3>Please log in to view your account</h3>
        <Link to="/login" className="btn btn-secondary" style={{ marginTop: 12 }}>Login</Link>
      </div>
    )
  }

  async function saveProfile(e) {
    e.preventDefault()
    await supabase.from('profiles').update(form).eq('id', user.id)
    refreshProfile()
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  async function deleteAddress(id) {
    await supabase.from('addresses').delete().eq('id', id)
    setAddresses(prev => prev.filter(a => a.id !== id))
  }

  return (
    <div className="container" style={{ paddingBottom: 50 }}>
      <div className="page-head"><h1>My Account</h1></div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24, maxWidth: 800 }}>
        <div className="summary-card">
          <h3>Profile Details</h3>
          {saved && <div className="form-success">Profile updated!</div>}
          <form onSubmit={saveProfile}>
            <div className="field"><label>Full Name</label><input value={form.full_name} onChange={e => setForm({ ...form, full_name: e.target.value })} /></div>
            <div className="field"><label>Phone</label><input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="field"><label>Email</label><input value={user.email} disabled style={{ opacity: 0.6 }} /></div>
            <button type="submit" className="btn btn-secondary">Save Changes</button>
          </form>
        </div>

        <div className="summary-card">
          <h3>Saved Addresses</h3>
          {addresses.length === 0 ? (
            <p style={{ fontSize: 13.5, color: 'var(--gray)' }}>No addresses saved yet. You'll be asked to add one at checkout.</p>
          ) : (
            addresses.map(addr => (
              <div key={addr.id} style={{ borderBottom: '1px solid var(--border)', padding: '10px 0', fontSize: 13.5 }}>
                <strong>{addr.full_name}</strong> · {addr.phone}<br />
                <span style={{ color: 'var(--gray)' }}>{addr.line1}, {addr.city}, {addr.state} - {addr.pincode}</span>
                <div><button className="icon-btn" onClick={() => deleteAddress(addr.id)}>Remove</button></div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
