import { useEffect, useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useCart } from '../context/CartContext'
import { useAuth } from '../context/AuthContext'

export default function ProductDetail({ onNeedLogin }) {
  const { slug } = useParams()
  const navigate = useNavigate()
  const { user } = useAuth()
  const { items, addToCart, updateQuantity } = useCart()
  const [product, setProduct] = useState(null)
  const [category, setCategory] = useState(null)
  const [reviews, setReviews] = useState([])
  const [loading, setLoading] = useState(true)
  const [related, setRelated] = useState([])

  useEffect(() => {
    async function load() {
      setLoading(true)
      const { data: p } = await supabase.from('products').select('*').eq('slug', slug).single()
      setProduct(p)
      if (p) {
        const { data: cat } = await supabase.from('categories').select('*').eq('id', p.category_id).single()
        setCategory(cat)
        const { data: rev } = await supabase
          .from('reviews')
          .select('*, profile:profiles(full_name)')
          .eq('product_id', p.id)
          .order('created_at', { ascending: false })
        setReviews(rev || [])
        const { data: rel } = await supabase
          .from('products')
          .select('*')
          .eq('category_id', p.category_id)
          .neq('id', p.id)
          .eq('is_active', true)
          .limit(4)
        setRelated(rel || [])
      }
      setLoading(false)
    }
    load()
  }, [slug])

  if (loading) return <div className="spinner-wrap">Loading…</div>
  if (!product) return (
    <div className="empty-state">
      <span className="emoji">🔍</span>
      <h3>Product not found</h3>
      <Link to="/" className="btn btn-secondary" style={{ marginTop: 12 }}>Back to home</Link>
    </div>
  )

  const cartLine = items.find(i => i.product.id === product.id)
  const offPct = product.mrp > product.price ? Math.round(((product.mrp - product.price) / product.mrp) * 100) : 0

  function handleAdd() {
    if (!user) { onNeedLogin?.(); return }
    addToCart(product.id, 1)
  }

  function buyNow() {
    if (!user) { onNeedLogin?.(); return }
    if (!cartLine) addToCart(product.id, 1)
    navigate('/cart')
  }

  return (
    <div className="container">
      <div className="breadcrumb" style={{ marginTop: 20 }}>
        <Link to="/">Home</Link> / {category && <Link to={`/category/${category.slug}`}>{category.name}</Link>} / {product.name}
      </div>

      <div className="pdp">
        <div className="pdp-image">
          <img src={product.image_url} alt={product.name} />
        </div>
        <div className="pdp-info">
          <span className="product-brand">{product.brand}</span>
          <h1>{product.name}</h1>
          <span className="product-unit">{product.unit}</span>
          {product.rating > 0 && (
            <div style={{ margin: '10px 0' }}>
              <span className="product-rating">★ {product.rating} <span style={{ opacity: 0.7 }}>({product.rating_count} ratings)</span></span>
            </div>
          )}
          <div className="pdp-price-block">
            <span className="now">₹{product.price}</span>
            {offPct > 0 && <span className="mrp">₹{product.mrp}</span>}
            {offPct > 0 && <span className="off">{offPct}% OFF</span>}
          </div>
          <p style={{ color: 'var(--ink)', fontSize: 14.5, lineHeight: 1.6, maxWidth: 480 }}>{product.description}</p>

          {product.stock === 0 ? (
            <p style={{ color: 'var(--orange-dark)', fontWeight: 700, marginTop: 16 }}>Out of stock</p>
          ) : (
            <div style={{ display: 'flex', gap: 14, marginTop: 24, flexWrap: 'wrap', alignItems: 'center' }}>
              {cartLine ? (
                <div className="qty-stepper" style={{ width: 140 }}>
                  <button onClick={() => updateQuantity(cartLine.id, cartLine.quantity - 1)}>−</button>
                  <span>{cartLine.quantity}</span>
                  <button onClick={() => updateQuantity(cartLine.id, cartLine.quantity + 1)}>+</button>
                </div>
              ) : (
                <button className="btn btn-outline" onClick={handleAdd}>Add to Cart</button>
              )}
              <button className="btn btn-primary" onClick={buyNow}>Buy Now</button>
            </div>
          )}
          <p style={{ fontSize: 12.5, color: 'var(--gray)', marginTop: 18 }}>
            {product.stock > 5 ? `✓ In stock (${product.stock} available)` : product.stock > 0 ? `⚠ Low stock — only ${product.stock} left` : ''}
          </p>
        </div>
      </div>

      <section style={{ padding: '24px 0 50px', maxWidth: 700 }}>
        <h2 style={{ fontSize: 18, color: 'var(--green-dark)', marginBottom: 14 }}>Customer Reviews</h2>
        {reviews.length === 0 ? (
          <p style={{ color: 'var(--gray)', fontSize: 14 }}>No reviews yet. Be the first to review this product after ordering.</p>
        ) : (
          reviews.map(r => (
            <div key={r.id} style={{ borderBottom: '1px solid var(--border)', padding: '12px 0' }}>
              <div style={{ fontWeight: 700, fontSize: 13.5 }}>★ {r.rating} · {r.profile?.full_name || 'Anonymous'}</div>
              {r.comment && <p style={{ fontSize: 13.5, color: 'var(--ink)', marginTop: 4 }}>{r.comment}</p>}
            </div>
          ))
        )}
      </section>

      {related.length > 0 && (
        <section className="section" style={{ paddingTop: 0 }}>
          <div className="section-head"><h2>You may also like</h2></div>
          <div className="product-grid">
            {related.map(p => (
              <Link key={p.id} to={`/product/${p.slug}`} className="product-card" style={{ textDecoration: 'none' }}>
                <img src={p.image_url} alt={p.name} />
                <div className="product-body">
                  <span className="product-brand">{p.brand}</span>
                  <div className="product-name">{p.name}</div>
                  <span className="product-unit">{p.unit}</span>
                  <div className="price-tag"><span className="price-now">₹{p.price}</span></div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
