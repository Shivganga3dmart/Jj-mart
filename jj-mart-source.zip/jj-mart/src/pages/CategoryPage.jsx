import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import ProductCard from '../components/ProductCard'

export default function CategoryPage({ onNeedLogin }) {
  const { slug } = useParams()
  const [category, setCategory] = useState(null)
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [sort, setSort] = useState('popular')

  useEffect(() => {
    async function load() {
      setLoading(true)
      const { data: cat } = await supabase.from('categories').select('*').eq('slug', slug).single()
      setCategory(cat)
      if (cat) {
        let query = supabase.from('products').select('*').eq('category_id', cat.id).eq('is_active', true)
        const { data: prods } = await query
        setProducts(prods || [])
      }
      setLoading(false)
    }
    load()
  }, [slug])

  const sorted = [...products].sort((a, b) => {
    if (sort === 'price_low') return a.price - b.price
    if (sort === 'price_high') return b.price - a.price
    if (sort === 'rating') return b.rating - a.rating
    return b.rating_count - a.rating_count
  })

  return (
    <div className="container">
      <div className="page-head">
        <div className="breadcrumb"><Link to="/">Home</Link> / {category?.name || '...'}</div>
        <h1>{category?.icon} {category?.name}</h1>
      </div>

      <div style={{ display: 'flex', gap: 10, margin: '16px 0', alignItems: 'center' }}>
        <span style={{ fontSize: 13, color: 'var(--gray)', fontWeight: 600 }}>Sort by:</span>
        {[
          ['popular', 'Popularity'],
          ['price_low', 'Price: Low to High'],
          ['price_high', 'Price: High to Low'],
          ['rating', 'Rating'],
        ].map(([val, label]) => (
          <button
            key={val}
            onClick={() => setSort(val)}
            className="btn"
            style={{
              padding: '6px 14px',
              fontSize: 12.5,
              background: sort === val ? 'var(--green)' : 'var(--white)',
              color: sort === val ? 'var(--white)' : 'var(--ink)',
              border: '1px solid var(--border)',
            }}
          >
            {label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="spinner-wrap">Loading…</div>
      ) : sorted.length === 0 ? (
        <div className="empty-state">
          <span className="emoji">🛒</span>
          <h3>No products here yet</h3>
          <p>Check back soon — we're stocking this aisle.</p>
        </div>
      ) : (
        <div className="product-grid" style={{ paddingBottom: 40 }}>
          {sorted.map(p => <ProductCard key={p.id} product={p} onNeedLogin={onNeedLogin} />)}
        </div>
      )}
    </div>
  )
}
