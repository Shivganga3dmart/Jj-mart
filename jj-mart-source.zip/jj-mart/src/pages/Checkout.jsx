import { useEffect, useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useAuth } from '../context/AuthContext'
import { useCart } from '../context/CartContext'

export default function Checkout() {
  const { user, profile } = useAuth()
  const { items, subtotal, clearCart } = useCart()
  const navigate = useNavigate()

  const [addresses, setAddresses] = useState([])
  const [selectedAddr, setSelectedAddr] = useState(null)
  const [showForm, setShowForm] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState('cod')
  const [placing, setPlacing] = useState(false)
  const [error, setError] = useState('')

  const [form, setForm] = useState({
    full_name: profile?.full_name || '', phone: profile?.phone || '',
    line1: '', line2: '', city: '', state: '', pincode: ''
  })

  useEffect(() => {
    if (!user) return
    supabase.from('addresses').select('*').eq('user_id', user.id).order('is_default', { ascending: false })
      .then(({ data }) => {
        setAddresses(data || [])
        if (data && data.length > 0) setSelectedAddr(data[0].id)
        else setShowForm(true)
      })
  }, [user])

  if (!user) {
    return (
      <div className="empty-state">
        <span className="emoji">🔒</span>
        <h3>Please log in to checkout</h3>
        <Link to="/login" className="btn btn-secondary" style={{ marginTop: 12 }}>Login</Link>
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="empty-state">
        <span className="emoji">🛒</span>
        <h3>Your cart is empty</h3>
        <Link to="/" className="btn btn-secondary" style={{ marginTop: 12 }}>Start Shopping</Link>
      </div>
    )
  }

  const deliveryFee = subtotal >= 299 ? 0 : 25
  const total = subtotal + deliveryFee

  async function saveAddress(e) {
    e.preventDefault()
    setError('')
    if (!form.full_name || !form.phone || !form.line1 || !form.city || !form.state || !form.pincode) {
      setError('Please fill in all required fields.')
      return
    }
    const { data, error: err } = await supabase
      .from('addresses')
      .insert({ ...form, user_id: user.id, is_default: addresses.length === 0 })
      .select()
      .single()
    if (err) { setError(err.message); return }
    setAddresses(prev => [...prev, data])
    setSelectedAddr(data.id)
    setShowForm(false)
  }

  async function placeOrder() {
    setError('')
    if (!selectedAddr) { setError('Please select or add a delivery address.'); return }
    setPlacing(true)

    const addr = addresses.find(a => a.id === selectedAddr)
    const addressText = `${addr.line1}${addr.line2 ? ', ' + addr.line2 : ''}, ${addr.city}, ${addr.state} - ${addr.pincode}`

    // Re-check stock right before placing the order
    for (const line of items) {
      const { data: fresh } = await supabase.from('products').select('stock').eq('id', line.product.id).single()
      if (!fresh || fresh.stock < line.quantity) {
        setError(`Sorry, "${line.product.name}" doesn't have enough stock. Please update your cart.`)
        setPlacing(false)
        return
      }
    }

    const { data: order, error: orderErr } = await supabase.from('orders').insert({
      user_id: user.id,
      address_id: selectedAddr,
      status: 'placed',
      payment_method: paymentMethod,
      payment_status: paymentMethod === 'cod' ? 'pending' : 'paid',
      subtotal, delivery_fee: deliveryFee, total,
      delivery_name: addr.full_name, delivery_phone: addr.phone, delivery_address: addressText
    }).select().single()

    if (orderErr) { setError(orderErr.message); setPlacing(false); return }

    const orderItems = items.map(line => ({
      order_id: order.id, product_id: line.product.id, product_name: line.product.name,
      unit: line.product.unit, price: line.product.price, quantity: line.quantity
    }))
    const { error: itemsErr } = await supabase.from('order_items').insert(orderItems)
    if (itemsErr) { setError(itemsErr.message); setPlacing(false); return }

    // Decrement stock for each product
    for (const line of items) {
      await supabase.from('products')
        .update({ stock: line.product.stock - line.quantity })
        .eq('id', line.product.id)
    }

    await clearCart()
    setPlacing(false)
    navigate(`/orders?placed=${order.id}`)
  }

  return (
    <div className="container">
      <div className="page-head"><h1>Checkout</h1></div>
      {error && <div className="form-error" style={{ maxWidth: 600 }}>{error}</div>}

      <div className="cart-layout" style={{ paddingBottom: 50 }}>
        <div>
          <div className="summary-card" style={{ marginBottom: 20 }}>
            <h3>Delivery Address</h3>
            {addresses.map(addr => (
              <label key={addr.id} style={{ display: 'flex', gap: 10, padding: '10px 0', borderBottom: '1px solid var(--border)', cursor: 'pointer', alignItems: 'flex-start' }}>
                <input type="radio" name="addr" checked={selectedAddr === addr.id} onChange={() => setSelectedAddr(addr.id)} style={{ marginTop: 4 }} />
                <div style={{ fontSize: 13.5 }}>
                  <strong>{addr.full_name}</strong> · {addr.phone}<br />
                  <span style={{ color: 'var(--gray)' }}>{addr.line1}{addr.line2 ? ', ' + addr.line2 : ''}, {addr.city}, {addr.state} - {addr.pincode}</span>
                </div>
              </label>
            ))}
            {!showForm && (
              <button className="btn btn-outline" style={{ marginTop: 14 }} onClick={() => setShowForm(true)}>+ Add new address</button>
            )}

            {showForm && (
              <form onSubmit={saveAddress} style={{ marginTop: 16 }}>
                <div className="field"><label>Full name *</label><input value={form.full_name} onChange={e => setForm({ ...form, full_name: e.target.value })} /></div>
                <div className="field"><label>Phone *</label><input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} /></div>
                <div className="field"><label>Address line 1 *</label><input value={form.line1} onChange={e => setForm({ ...form, line1: e.target.value })} /></div>
                <div className="field"><label>Address line 2</label><input value={form.line2} onChange={e => setForm({ ...form, line2: e.target.value })} /></div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
                  <div className="field"><label>City *</label><input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} /></div>
                  <div className="field"><label>State *</label><input value={form.state} onChange={e => setForm({ ...form, state: e.target.value })} /></div>
                </div>
                <div className="field"><label>Pincode *</label><input value={form.pincode} onChange={e => setForm({ ...form, pincode: e.target.value })} /></div>
                <div style={{ display: 'flex', gap: 10 }}>
                  <button type="submit" className="btn btn-secondary">Save Address</button>
                  {addresses.length > 0 && <button type="button" className="btn btn-outline" onClick={() => setShowForm(false)}>Cancel</button>}
                </div>
              </form>
            )}
          </div>

          <div className="summary-card">
            <h3>Payment Method</h3>
            <label style={{ display: 'flex', gap: 10, padding: '8px 0', cursor: 'pointer' }}>
              <input type="radio" checked={paymentMethod === 'cod'} onChange={() => setPaymentMethod('cod')} />
              <span style={{ fontSize: 14 }}>Cash on Delivery</span>
            </label>
            <label style={{ display: 'flex', gap: 10, padding: '8px 0', cursor: 'pointer', opacity: 0.5 }}>
              <input type="radio" disabled checked={paymentMethod === 'online'} onChange={() => setPaymentMethod('online')} />
              <span style={{ fontSize: 14 }}>Online Payment (UPI/Card) — coming soon</span>
            </label>
          </div>
        </div>

        <div className="summary-card">
          <h3>Order Summary</h3>
          {items.map(line => (
            <div className="order-item-row" key={line.id}>
              <span>{line.product.name} × {line.quantity}</span>
              <span>₹{(line.product.price * line.quantity).toFixed(0)}</span>
            </div>
          ))}
          <div className="summary-row" style={{ marginTop: 10 }}><span>Subtotal</span><span>₹{subtotal.toFixed(0)}</span></div>
          <div className="summary-row"><span>Delivery</span><span className={deliveryFee === 0 ? 'free' : ''}>{deliveryFee === 0 ? 'FREE' : `₹${deliveryFee}`}</span></div>
          <div className="summary-row total"><span>Total</span><span>₹{total.toFixed(0)}</span></div>
          <button className="btn btn-primary" style={{ width: '100%', marginTop: 16 }} disabled={placing} onClick={placeOrder}>
            {placing ? 'Placing order…' : `Place Order — ₹${total.toFixed(0)}`}
          </button>
        </div>
      </div>
    </div>
  )
}
