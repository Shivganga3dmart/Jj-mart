import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './AuthContext'

const CartContext = createContext(null)

export function CartProvider({ children }) {
  const { user } = useAuth()
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)

  const refresh = useCallback(async () => {
    if (!user) {
      setItems([])
      return
    }
    setLoading(true)
    const { data } = await supabase
      .from('cart_items')
      .select('id, quantity, product:products(*)')
      .eq('user_id', user.id)
      .order('created_at', { ascending: true })
    setItems(data || [])
    setLoading(false)
  }, [user])

  useEffect(() => { refresh() }, [refresh])

  async function addToCart(productId, qty = 1) {
    if (!user) return { error: 'not_logged_in' }
    const existing = items.find(i => i.product.id === productId)
    if (existing) {
      await supabase.from('cart_items').update({ quantity: existing.quantity + qty }).eq('id', existing.id)
    } else {
      await supabase.from('cart_items').insert({ user_id: user.id, product_id: productId, quantity: qty })
    }
    await refresh()
    return { error: null }
  }

  async function updateQuantity(cartItemId, qty) {
    if (qty <= 0) {
      await supabase.from('cart_items').delete().eq('id', cartItemId)
    } else {
      await supabase.from('cart_items').update({ quantity: qty }).eq('id', cartItemId)
    }
    await refresh()
  }

  async function removeItem(cartItemId) {
    await supabase.from('cart_items').delete().eq('id', cartItemId)
    await refresh()
  }

  async function clearCart() {
    if (!user) return
    await supabase.from('cart_items').delete().eq('user_id', user.id)
    await refresh()
  }

  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0)
  const subtotal = items.reduce((sum, i) => sum + i.quantity * Number(i.product.price), 0)

  return (
    <CartContext.Provider value={{ items, loading, addToCart, updateQuantity, removeItem, clearCart, refresh, itemCount, subtotal }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  return useContext(CartContext)
}
